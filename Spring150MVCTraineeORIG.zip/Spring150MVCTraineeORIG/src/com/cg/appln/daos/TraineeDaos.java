package com.cg.appln.daos;

import java.util.List;

import com.cg.appln.entities.Trainee;
import com.cg.appln.exception.TraineeException;

public interface TraineeDaos {

	Trainee getTraineeDetails(int traineeId)throws TraineeException;
	List<Trainee> getTraineeList()throws TraineeException;
	Trainee addTrainee(Trainee trainee)throws TraineeException;
}
