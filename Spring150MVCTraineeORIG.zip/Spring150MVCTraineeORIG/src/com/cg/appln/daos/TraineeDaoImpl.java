package com.cg.appln.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;


import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appln.entities.Trainee;
import com.cg.appln.exception.TraineeException;

@Repository("traineeDao")
public class TraineeDaoImpl implements TraineeDaos {

	private EntityManagerFactory factory;

	@Resource(name="entityMFactory")
	public void setEntityManagerFactory(EntityManagerFactory factory){
		this.factory= factory;
	}
	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
		EntityManager manager= factory.createEntityManager();
		Trainee trainee= manager.find(Trainee.class, traineeId);
		
		return trainee;
	}
	@Override
	public List<Trainee> getTraineeList() throws TraineeException {
		String qryStr= "SELECT t FROM trainee t";
		EntityManager manager= factory.createEntityManager();
		Query qry= manager.createQuery(qryStr, Trainee.class);
		return qry.getResultList();
	}
	@Override
	public Trainee addTrainee(Trainee trainee) throws TraineeException {
		try {
			EntityManager manager= factory.createEntityManager();
			manager.getTransaction().begin();
			manager.persist(trainee);
			manager.getTransaction().commit();
			return trainee;
		} catch (RollbackException e) {
			throw new TraineeException("Could not insert!");
		}
	}

}
