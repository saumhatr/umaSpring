package com.cg.appln.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appln.entities.Trainee;
import com.cg.appln.exception.TraineeException;
import com.cg.appln.services.TraineeService;

@Controller
public class TraineeCrudController {

	private TraineeService services;
	
	private List<String> domainList=null;
	private List<String> locationList= null;
	
	@PostConstruct
	public void initialize(){
		domainList= new ArrayList<String>();	
		domainList.add("JAVA");
		domainList.add(".Net");
		
		locationList= new ArrayList<String>();
		locationList.add("Mumbai");
		locationList.add("Pune");
	}
	@Resource(name="traineeServices")
	public void setTraineeService(TraineeService services){
		this.services= services;
	}
	
	@RequestMapping("/home.do")
	public ModelAndView getHomePage(){
		ModelAndView modView= new ModelAndView("home");
		return modView;
	}
	
	@RequestMapping("enterTraineeNo.do")
	public ModelAndView enterTraineeNumber(){
		ModelAndView modView= new ModelAndView("myForm");
		return modView;
	}
	
	@RequestMapping("showTraineeDetails.do")
	public ModelAndView showDetails(@RequestParam("traineeNo") int traineeNo){
		ModelAndView modView= null;
		try {
			Trainee trainee= services.getTraineeDetails(traineeNo);
			modView= new ModelAndView("traineeDetails");
			modView.addObject("traineeDetails", trainee);
			return modView;
		} catch (TraineeException e) {
			// TODO Auto-generated catch block
			modView= new ModelAndView("error");
			modView.addObject("message", e.getMessage());
		}
		return modView;		
	}
	
	@RequestMapping("listAllTrainees.do")
	public ModelAndView showAllTrainees(){
		ModelAndView modView=null;
		try {
			List<Trainee> traineeList= services.getTraineeList();
			modView= new ModelAndView("listAllTrainees");
			modView.addObject("trainees", traineeList);
		} catch (TraineeException e) {
			modView=new ModelAndView("error");
			modView.addObject("message", e.getMessage());
		}
		return modView;		
	}
	
	@RequestMapping("entryForm.do")
	public ModelAndView getTraineeEntryForm(){
		ModelAndView modView= new ModelAndView("entryForm");
		modView.addObject("trainee", new Trainee()); // pass trainee object to jsp page where it will be populated
		modView.addObject("domains", domainList);
		modView.addObject("locations", locationList);
		return modView;
	}
	
	@RequestMapping("submitEntryForm.do")
	public ModelAndView submitTraineeEntry(@ModelAttribute @Valid Trainee trainee, BindingResult result ){
		ModelAndView modView= new ModelAndView();
		
		if(result.hasErrors()){	
			modView.setViewName("entryForm");
			modView.addObject("trainee", new Trainee()); // pass trainee object to jsp page where it will be populated
			modView.addObject("domains", domainList);
			modView.addObject("locations", locationList);
			return modView;
		}
		try {
			Trainee traineeResponse = services.addTrainee(trainee);
			modView.setViewName("successAdd");
			modView.addObject("trainee", traineeResponse);
		} catch (TraineeException e) {
			modView.setViewName("error");
			modView.addObject("message", "Insertion failed: "+ e.getMessage());
		}
		return modView;
	}
	
	//////for Updation
	@RequestMapping("updateTrainee.do")
	public ModelAndView updateTrainee(@RequestParam("id") int traineeNo){
		System.out.println(traineeNo);
		ModelAndView modView= null;
		modView= new ModelAndView("error");
		return modView.addObject("message", "dummy message");
	}
	
}
