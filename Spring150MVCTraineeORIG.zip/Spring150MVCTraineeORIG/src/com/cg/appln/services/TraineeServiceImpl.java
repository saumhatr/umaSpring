package com.cg.appln.services;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;



import com.cg.appln.daos.TraineeDaoImpl;
import com.cg.appln.daos.TraineeDaos;
import com.cg.appln.entities.Trainee;
import com.cg.appln.exception.TraineeException;

@Service("traineeServices")
public class TraineeServiceImpl implements TraineeService {

	private TraineeDaos dao;
	
	@Resource(name="traineeDao")
	public void setTraineeDao(TraineeDaos dao) {
		this.dao= dao;
	}

	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
		
		return dao.getTraineeDetails(traineeId);
	}

	@Override
	public List<Trainee> getTraineeList() throws TraineeException {
		
		return dao.getTraineeList();
	}

	@Override
	@Transactional
	public Trainee addTrainee(Trainee trainee) throws TraineeException {
		
		return dao.addTrainee(trainee);
	}

}
