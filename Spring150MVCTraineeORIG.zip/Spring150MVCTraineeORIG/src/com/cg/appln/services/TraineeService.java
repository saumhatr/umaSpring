package com.cg.appln.services;

import java.util.List;

import com.cg.appln.entities.Trainee;
import com.cg.appln.exception.TraineeException;

public interface TraineeService {
	Trainee getTraineeDetails(int traineeId)throws TraineeException;
	List<Trainee> getTraineeList()throws TraineeException;
	
	Trainee addTrainee(Trainee trainee)throws TraineeException;
}
